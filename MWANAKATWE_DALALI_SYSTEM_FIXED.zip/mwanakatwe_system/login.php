<?php
require_once __DIR__.'/config.php';
if (logged_in()) redirect();
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $phone=trim($_POST['phone']??''); $password=$_POST['password']??'';
    try {
        $stmt=db()->prepare('SELECT id,full_name,phone,password,role FROM users WHERE phone=? LIMIT 1');
        $stmt->execute([$phone]); $user=$stmt->fetch();
        if ($user && password_verify($password,$user['password'])) {
            session_regenerate_id(true);
            unset($user['password']); $_SESSION['user']=$user;
            redirect();
        }
        $error='Namba ya simu au nywila si sahihi.';
    } catch(Throwable $ex) { $error='Database haijaunganishwa. Fungua setup.php kwanza na hakikisha MySQL imewashwa.'; }
}
?>
<!doctype html><html lang="sw"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ingia | Mwanakatwe Dalali</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-page"><div class="auth-layout"><section class="auth-promo"><a class="brand light" href="index.php"><span class="brand-mark">M</span><span>MWANAKATWE<strong>DALALI</strong></span></a><div class="promo-copy"><span class="eyebrow">SOKO LA MALI MTANDAONI</span><h1>Pata mali.<br><em>Uza kwa urahisi.</em></h1><p>Jukwaa moja la kuunganisha wanunuzi na wauzaji wa nyumba, viwanja, magari na bidhaa mbalimbali.</p><div class="promo-stats"><div><b>Rahisi</b><small>kutumia</small></div><div><b>Salama</b><small>na linaloaminika</small></div><div><b>Haraka</b><small>kupata matangazo</small></div></div></div><div class="promo-foot">© <?=date('Y')?> Mwanakatwe Dalali</div></section>
<section class="auth-form-wrap"><form class="auth-form" method="post"><span class="eyebrow">KARIBU TENA</span><h2>Ingia kwenye akaunti</h2><p class="muted">Weka taarifa zako ili kuendelea.</p>
<?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<label>Namba ya simu</label><input class="field" name="phone" type="tel" placeholder="Mf. 07XXXXXXXX" required autocomplete="username">
<label>Nywila</label><input class="field" name="password" type="password" placeholder="Weka nywila yako" required autocomplete="current-password">
<button class="btn btn-primary btn-block" type="submit">Ingia <span>→</span></button><p class="form-bottom">Huna akaunti? <a href="register.php">Jisajili hapa</a></p></form></section></div></body></html>
