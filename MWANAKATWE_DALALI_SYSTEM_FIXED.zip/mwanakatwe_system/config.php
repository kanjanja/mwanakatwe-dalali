<?php
declare(strict_types=1);
session_start();

const DB_HOST = 'localhost';
const DB_NAME = 'mwanakatwe_dalali';
const DB_USER = 'root';
const DB_PASS = '';
const APP_NAME = 'Mwanakatwe Dalali';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function logged_in(): bool { return isset($_SESSION['user']['id']); }
function is_admin(): bool { return logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin'; }
function require_login(): void { if (!logged_in()) { header('Location: login.php'); exit; } }
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
            http_response_code(419); exit('Ombi limeisha muda. Rudi nyuma na ujaribu tena.');
        }
    }
}
function flash(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type, 'message'=>$message]; }
function redirect(string $url='index.php'): never { header('Location: '.$url); exit; }
function money($amount): string { return 'TSh ' . number_format((float)$amount, 0); }
