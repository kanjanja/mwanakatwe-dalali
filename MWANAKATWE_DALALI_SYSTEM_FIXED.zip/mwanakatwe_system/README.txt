MWANAKATWE DALALI SYSTEM - TOLEO LILILOREKEBISHWA

MAHITAJI
- XAMPP (PHP 8.0+ na MySQL/MariaDB)
- Browser ya kisasa

KUANZISHA KWENYE XAMPP
1. Extract folder mwanakatwe_system ndani ya C:\xampp\htdocs\
2. Fungua XAMPP Control Panel na Start Apache pamoja na MySQL.
3. Hakikisha config.php ina taarifa sahihi za MySQL:
   DB_HOST = localhost
   DB_NAME = mwanakatwe_dalali
   DB_USER = root
   DB_PASS = '' (kwa XAMPP ya kawaida)
4. Fungua http://localhost/mwanakatwe_system/setup.php
5. Baada ya setup kufanikiwa, ingia kupitia:
   http://localhost/mwanakatwe_system/login.php

AKAUNTI YA ADMIN YA MWANZO
Simu: 0700000000
Nywila: Mwanakatwe2026

MUHIMU KWA USALAMA
- Badilisha nywila ya admin mara tu unapoingia.
- Futa setup.php baada ya usanidi kukamilika.
- Badilisha DB_USER na DB_PASS kwa hosting yako.
- Hakikisha folder uploads lina ruhusa ya kuandikiwa na PHP.
- Washa HTTPS kabla ya kutumia mfumo hadharani.

VIPENGELE
- Login na usajili
- Dashboard ya mtumiaji na Admin
- Kutengeneza matangazo na kupakia picha
- Admin kuidhinisha/kukataa/kufuta matangazo
- Utafutaji na vichujio vya matangazo
- Password hashing, prepared statements, CSRF token na session regeneration

KUMBUKA
Huu ni mfumo wa msingi wa matangazo na usimamizi. Mfumo wa malipo ya moja kwa moja haujaunganishwa na mtoa huduma wa malipo; payment code ni sehemu ya kurekodi kumbukumbu tu.
