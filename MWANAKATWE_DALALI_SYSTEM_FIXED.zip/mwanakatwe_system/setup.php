<?php
require_once __DIR__.'/config.php';
$error = '';
$done = false;
try {
    $server = new PDO('mysql:host='.DB_HOST.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION
    ]);
    $server->exec("CREATE DATABASE IF NOT EXISTS `".str_replace('`','',DB_NAME)."` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $server->exec("USE `".str_replace('`','',DB_NAME)."`");
    $server->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
        role ENUM('admin','user') NOT NULL DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");
    $server->exec("CREATE TABLE IF NOT EXISTS listings (
        id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
        title VARCHAR(150) NOT NULL,
        category ENUM('Nyumba','Viwanja','Magari','Vifaa vya Ndani','Vingine') NOT NULL,
        price DECIMAL(15,2) NOT NULL, location VARCHAR(100) NOT NULL,
        description TEXT NOT NULL, image_path VARCHAR(255) DEFAULT NULL,
        package_type ENUM('Kawaida','VIP') NOT NULL DEFAULT 'Kawaida',
        payment_code VARCHAR(50) DEFAULT NULL,
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_listing_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
    $check=$server->prepare("SELECT id FROM users WHERE phone=?");
    $check->execute(['0700000000']);
    if (!$check->fetch()) {
        $ins=$server->prepare("INSERT INTO users(full_name,phone,password,role) VALUES(?,?,?, 'admin')");
        $ins->execute(['Mwanakatwe Admin','0700000000',password_hash('Mwanakatwe2026',PASSWORD_DEFAULT)]);
    }
    if (!is_dir(__DIR__.'/uploads')) mkdir(__DIR__.'/uploads',0755,true);
    $done=true;
} catch(Throwable $ex) { $error=$ex->getMessage(); }
?>
<!doctype html><html lang="sw"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Usanidi wa Mwanakatwe Dalali</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="setup-page"><main class="setup-card">
<div class="brand-mark">M</div><p class="eyebrow">MWANAKATWE DALALI</p>
<?php if($done): ?><div class="success-icon">✓</div><h1>Usanidi umekamilika</h1><p>Database na majedwali yameundwa na akaunti ya msimamizi iko tayari.</p>
<div class="credentials"><span>Simu ya Admin</span><strong>0700000000</strong><span>Nywila ya mwanzo</span><strong>Mwanakatwe2026</strong></div>
<p class="notice">Kwa usalama, badilisha nywila baada ya kuingia na futa au linda faili la setup.php.</p><a class="btn btn-primary btn-block" href="login.php">Ingia kwenye mfumo <span>→</span></a>
<?php else: ?><h1>Usanidi haujakamilika</h1><p class="notice error"><?=e($error)?></p><p>Hakikisha MySQL imewashwa na taarifa za database kwenye config.php ni sahihi.</p><a class="btn btn-primary" href="setup.php">Jaribu tena</a><?php endif; ?>
</main></body></html>
